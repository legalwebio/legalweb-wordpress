=== LegalWeb Cloud ===
Contributors: legalweb
Donate link: https://legalweb.io
Tags: wordpress
Requires at least: 3.0.1
Tested up to: 5.4.2
Stable tag: 1.0.0
Requires PHP: 5.6.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 Wordpress Plugin for GDPR/DSGVO, Imprint & Pricacy Policy and other legal texts to use with the legalweb.io cloud service.

== Description ==

With this plugin, you can use the legalweb.io cloud service with your Wordpress page. It connects to the legalweb.io web API and fetches your legal texts, integrations to insert it in your Wordpress Page.

== Installation ==

Just install via wordpress plugin feature or upload zip and activate it.

== Screenshots ==

== Changelog ==
= 1.0.0 =
* initial commit
