<?php

class LwWordpressConstants
{


    const OPTIONS_PREFIX = "lw_wp_";
	const USER_META_KEY = "lw_wordpress";
	const COOKIE_NAME = 'lw_wordpress';



	const LW_API_BASE_URL = "https://dev.legalweb.io/api";

}